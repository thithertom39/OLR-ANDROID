package org.openxray;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/** Static, decorative artwork for the launcher only. */
public final class LauncherBackdropView extends View {
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final RectF target = new RectF();
    private final Bitmap backdrop;

    public LauncherBackdropView(Context context, AttributeSet attrs) {
        super(context, attrs);
        backdrop = BitmapFactory.decodeResource(getResources(), R.drawable.launcher_zone_background);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (backdrop == null) return;
        float scale = Math.max((float) getWidth() / backdrop.getWidth(),
                (float) getHeight() / backdrop.getHeight());
        target.set(0, 0, backdrop.getWidth() * scale, backdrop.getHeight() * scale);
        canvas.drawBitmap(backdrop, null, target, paint);
        if (getResources().getConfiguration().smallestScreenWidthDp < 600) {
            canvas.drawColor(0x600B0A08);
        }
    }
}
