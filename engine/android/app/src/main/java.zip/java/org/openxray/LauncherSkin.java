package org.openxray;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.content.res.ResourcesCompat;

/** Presentation only: no preferences, launch arguments or gameplay state. */
final class LauncherSkin {
    private static final int AMBER = 0xFFCCAC77;
    private static final int AQUA = 0xFF76BDB7;

    static void apply(Activity activity) {
        View root = activity.findViewById(R.id.launcher_root);
        Typeface body = ResourcesCompat.getFont(activity, R.font.launcher_body);
        Typeface heading = Build.VERSION.SDK_INT >= 28 ?
                Typeface.create(body, 600, false) : Typeface.create(body, Typeface.BOLD);
        Bitmap panel = BitmapFactory.decodeResource(activity.getResources(), R.drawable.launcher_monitor_panel);
        Bitmap button = BitmapFactory.decodeResource(activity.getResources(), R.drawable.launcher_monitor_button);
        decorate(root, body, heading, panel, button);
        if (activity.getResources().getConfiguration().smallestScreenWidthDp < 600) {
            activity.findViewById(R.id.launcher_hero).setVisibility(View.GONE);
            setWeight(activity.findViewById(R.id.launcher_settings_column), .58f);
            setWeight(activity.findViewById(R.id.launcher_actions_column), .42f);
        }
    }

    private static void setWeight(View view, float weight) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) view.getLayoutParams();
        params.weight = weight;
        view.setLayoutParams(params);
    }

    private static int dp(View view, float value) {
        return Math.round(value * view.getResources().getDisplayMetrics().density);
    }

    private static void decorate(View view, Typeface body, Typeface heading, Bitmap panel, Bitmap compact) {
        if ("zone_panel".equals(view.getTag())) {
            view.setBackground(new Plate(panel, view.getResources(), 0));
            // Keep controls inside the glass, clear of cables and the lower vent.
            view.setPadding(dp(view, 22), dp(view, 16), dp(view, 22), dp(view, 20));
        }
        if (view instanceof TextView) {
            TextView text = (TextView) view;
            text.setTypeface(body);
            text.setIncludeFontPadding(false);
            if ("zone_heading".equals(view.getTag())) {
                text.setTypeface(heading);
                text.setTextColor(AMBER);
                text.setLetterSpacing(.025f);
                text.setShadowLayer(dp(view, 1), 0, dp(view, 1), 0xFF16120C);
            }
        }
        if (view instanceof EditText) {
            view.setBackgroundTintList(null);
        }
        if (view instanceof CompoundButton) {
            CompoundButton button = (CompoundButton) view;
            button.setButtonTintList(null);
            button.setButtonDrawable(new Toggle(view.getResources(), view instanceof RadioButton));
            button.setMinimumHeight(dp(view, 26));
            button.setCompoundDrawablePadding(dp(view, 3));
        }
        if (view instanceof Button && !(view instanceof CompoundButton)) {
            Button button = (Button) view;
            int kind = view.getId() == R.id.btn_start_new_game ? 1 :
                    view.getId() == R.id.btn_start_game ? 2 : 3;
            if (button instanceof AppCompatButton) {
                ((AppCompatButton) button).setSupportBackgroundTintList(null);
            }
            button.setBackgroundTintList(null);
            button.setBackground(new Plate(compact, view.getResources(), kind));
            button.setTypeface(heading);
            button.setAllCaps(false);
            button.setMinimumHeight(0);
            button.setMinimumWidth(0);
            button.setLetterSpacing(.015f);
            button.setTextColor(kind == 2 ? 0xFFE4D7B8 :
                    view.getId() == R.id.btn_view_logs || view.getId() == R.id.btn_edit_touch_layout ?
                            AMBER : 0xFFE7E4D8);
            button.setShadowLayer(kind == 2 ? 0 : dp(view, 1), 0, dp(view, 1), 0xFF18120E);
        }
        if (view instanceof SeekBar) {
            SeekBar seek = (SeekBar) view;
            GradientDrawable track = new GradientDrawable();
            track.setColor(0xFF656460);
            track.setSize(dp(view, 1), dp(view, 2));
            GradientDrawable progress = new GradientDrawable();
            progress.setColor(AQUA);
            progress.setSize(dp(view, 1), dp(view, 2));
            LayerDrawable layers = new LayerDrawable(new Drawable[] {
                    track, new ClipDrawable(progress, Gravity.START, ClipDrawable.HORIZONTAL) });
            layers.setId(0, android.R.id.background);
            layers.setId(1, android.R.id.progress);
            layers.setLayerGravity(0, Gravity.CENTER_VERTICAL | Gravity.FILL_HORIZONTAL);
            layers.setLayerGravity(1, Gravity.CENTER_VERTICAL | Gravity.FILL_HORIZONTAL);
            layers.setLayerHeight(0, dp(view, 2));
            layers.setLayerHeight(1, dp(view, 2));
            seek.setProgressDrawable(layers);
            seek.setProgressTintList(ColorStateList.valueOf(AQUA));
            seek.setProgressBackgroundTintList(ColorStateList.valueOf(0xFF656460));
            GradientDrawable thumb = new GradientDrawable();
            thumb.setShape(GradientDrawable.OVAL);
            thumb.setColor(AQUA);
            thumb.setStroke(dp(view, 1), 0xFF9FDBD2);
            thumb.setSize(dp(view, 12), dp(view, 12));
            seek.setThumb(thumb);
            seek.setThumbTintList(ColorStateList.valueOf(AQUA));
            seek.setSplitTrack(false);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) view;
            for (int i = 0; i < group.getChildCount(); i++) {
                decorate(group.getChildAt(i), body, heading, panel, compact);
            }
        }
    }

    private static final class Toggle extends Drawable {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path tick = new Path();
        private final boolean radio;
        private final float density;
        private final int size;
        private boolean checked;

        Toggle(Resources resources, boolean radio) {
            this.radio = radio;
            density = resources.getDisplayMetrics().density;
            size = Math.round(20 * density);
        }
        @Override public int getIntrinsicWidth() { return size; }
        @Override public int getIntrinsicHeight() { return size; }
        @Override public boolean isStateful() { return true; }
        @Override protected boolean onStateChange(int[] states) {
            boolean value = false;
            for (int state : states) if (state == android.R.attr.state_checked) value = true;
            if (value != checked) { checked = value; invalidateSelf(); return true; }
            return false;
        }
        @Override public void draw(Canvas canvas) {
            Rect bounds = getBounds();
            float x = bounds.exactCenterX(), y = bounds.exactCenterY(), r = 7.7f * density;
            paint.setColor(checked ? AQUA : 0xFFD0CDC5);
            paint.setStrokeWidth(1.4f * density);
            paint.setStyle(Paint.Style.STROKE);
            if (radio) {
                canvas.drawCircle(x, y, r, paint);
                if (checked) {
                    paint.setStyle(Paint.Style.FILL);
                    canvas.drawCircle(x, y, 4.3f * density, paint);
                }
            } else if (!checked) {
                canvas.drawRect(x - r, y - r, x + r, y + r, paint);
            } else {
                paint.setStyle(Paint.Style.FILL);
                canvas.drawRect(x - r, y - r, x + r, y + r, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setColor(0xFF1C3431);
                paint.setStrokeWidth(1.8f * density);
                paint.setStrokeCap(Paint.Cap.ROUND);
                tick.reset();
                tick.moveTo(x - 4.1f * density, y);
                tick.lineTo(x - 1.1f * density, y + 3.2f * density);
                tick.lineTo(x + 4.6f * density, y - 3.5f * density);
                canvas.drawPath(tick, paint);
            }
        }
        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Fixed metal frame slices surround a quiet, opaque charcoal panel. */
    private static final class Plate extends Drawable {
        private final Bitmap bitmap;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        private final Paint glaze = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Rect source = new Rect();
        private final RectF destination = new RectF();
        private final RectF glass = new RectF();
        private final int[] sx;
        private final int[] sy;
        private final float[] dx = new float[4];
        private final float[] dy = new float[4];
        private final ColorFilter baseFilter;
        private final float side;
        private final float top;
        private final float bottom;
        private final int kind;
        private int alpha = 255;
        private boolean pressed;

        Plate(Bitmap bitmap, Resources resources, int kind) {
            this.bitmap = bitmap;
            this.kind = kind;
            float density = resources.getDisplayMetrics().density;
            side = (kind == 0 ? 20 : 8) * density;
            top = (kind == 0 ? 14 : 9) * density;
            bottom = (kind == 0 ? 18 : 9) * density;
            sx = kind == 0 ? new int[] {8, 192, 1344, 1528} : new int[] {32, 136, 1400, 1504};
            sy = kind == 0 ? new int[] {42, 176, 782, 952} : new int[] {172, 288, 720, 832};
            ColorMatrix muted = new ColorMatrix();
            muted.setSaturation(.55f);
            ColorMatrix darkness = new ColorMatrix(new float[] {
                    .83f, 0, 0, 0, 0, 0, .83f, 0, 0, 0,
                    0, 0, .83f, 0, 0, 0, 0, 0, 1, 0 });
            muted.postConcat(darkness);
            baseFilter = new ColorMatrixColorFilter(muted);
            paint.setColorFilter(baseFilter);
        }

        @Override public void draw(Canvas canvas) {
            if (bitmap == null) return;
            Rect bounds = getBounds();
            if (bounds.width() <= 0 || bounds.height() <= 0) return;
            float horizontal = Math.min(side, bounds.width() / 3f);
            float upper = Math.min(top, bounds.height() / 3f);
            float lower = Math.min(bottom, bounds.height() / 3f);
            dx[0] = bounds.left; dx[1] = bounds.left + horizontal;
            dx[2] = bounds.right - horizontal; dx[3] = bounds.right;
            dy[0] = bounds.top; dy[1] = bounds.top + upper;
            dy[2] = bounds.bottom - lower; dy[3] = bounds.bottom;
            paint.setAlpha(alpha);
            // Keep the original metal rim, but do not sample the cracked glass.
            // A solid muted olive/charcoal fill keeps labels clear without per-draw allocations.
            glass.set(dx[1], dy[1], dx[2], dy[2]);
            glaze.setColor(0xFF181A16);
            glaze.setAlpha(alpha);
            canvas.drawRect(glass, glaze);
            for (int row = 0; row < 3; row++) for (int column = 0; column < 3; column++) {
                if (row == 1 && column == 1) continue;
                source.set(sx[column], sy[row], sx[column + 1], sy[row + 1]);
                destination.set(dx[column], dy[row], dx[column + 1], dy[row + 1]);
                canvas.drawBitmap(bitmap, source, destination, paint);
            }
            if (kind == 1 || kind == 2) {
                glaze.setColor(kind == 1 ? 0xA0394C2D : 0xB0826429);
                glaze.setAlpha(Math.round(Color.alpha(glaze.getColor()) * alpha / 255f));
                canvas.drawRect(glass, glaze);
            }
            if (pressed) {
                glaze.setColor(0x22FFE0A0);
                glaze.setAlpha(Math.round(34 * alpha / 255f));
                canvas.drawRect(glass, glaze);
            }
        }

        @Override public boolean isStateful() { return true; }
        @Override protected boolean onStateChange(int[] states) {
            boolean active = false;
            for (int state : states) {
                if (state == android.R.attr.state_pressed || state == android.R.attr.state_focused) active = true;
            }
            if (active != pressed) { pressed = active; invalidateSelf(); return true; }
            return false;
        }
        @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter != null ? filter : baseFilter); invalidateSelf(); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
